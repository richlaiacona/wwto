
<footer>
	<center><br><p>Footer</p></center>
</footer>